/*
File name: exBmain.cpp
Assignment: Lab 2 Excerise B
Completed by: John Tumacder 
Submission date: Sept 23, 2024
*/


#include "graphicsWorld.h"

int main(){
    GraphicsWorld test;
    test.run();
    return 0;
};