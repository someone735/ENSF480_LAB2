/*
File name: graphicsWorld.h
Assignment: Lab 2 Excerise B
Completed by: John Tumacder 
Submission date: Sept 23, 2024
*/

#ifndef GWORLDS_H
#define GWORLDS_H
#include "point.h"
#include "shape.h"
#include "square.h"
#include "rectangle.h"
class GraphicsWorld
{
public:
    void run();
};
#endif